package com.inkvideo.maker

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

/** Tashqi fayl kerak emas: ovoz effektlari kod orqali sintez qilinadi. */
object Sfx {
    const val SR = 44100
    val names = listOf("Yo'q", "Shamol", "Pop", "Klik", "Svish", "Zarba", "Qo'ng'iroq")

    private val cache = HashMap<Int, ShortArray>()

    fun pcm(type: Int): ShortArray = synchronized(cache) { cache.getOrPut(type) { synth(type) } }

    private fun synth(type: Int): ShortArray {
        val rnd = java.util.Random(type * 1234L + 5)
        val dur = when (type) { 1 -> 0.38; 2 -> 0.14; 3 -> 0.04; 4 -> 0.26; 5 -> 0.42; 6 -> 0.7; else -> 0.05 }
        val n = (dur * SR).toInt()
        val out = ShortArray(n)
        var lp = 0.0
        var ph = 0.0
        var ph2 = 0.0
        val fadeIn = 0.002 * SR
        val fadeOut = 0.004 * SR
        for (i in 0 until n) {
            val u = i.toDouble() / n
            val noise = rnd.nextDouble() * 2 - 1
            val v: Double = when (type) {
                1 -> { val env = sin(PI * u).pow(2); lp += (0.02 + 0.35 * env) * (noise - lp); lp * env * 2.4 }
                2 -> { ph += 2 * PI * (900 - 700 * u) / SR; sin(ph) * exp(-u * 6) }
                3 -> noise * exp(-u * 9) * 0.8
                4 -> { val env = sin(PI * u).pow(1.5); lp += 0.5 * (noise - lp); (noise - lp) * env * 0.9 }
                5 -> { ph += 2 * PI * (110 - 70 * u) / SR; sin(ph) * exp(-u * 5) + noise * exp(-u * 30) * 0.3 }
                6 -> { ph += 2 * PI * 880 / SR; ph2 += 2 * PI * 1320 / SR; (sin(ph) + 0.5 * sin(ph2)) * exp(-u * 4.5) * 0.6 }
                else -> 0.0
            }
            val taper = minOf(1.0, i / fadeIn, (n - i) / fadeOut)
            out[i] = (v * taper * 0.8 * 32767).toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    /** Tahrirlagich ichida eshitib ko'rish uchun. */
    fun play(type: Int) {
        if (type <= 0) return
        try {
            val d = pcm(type)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(d.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(d, 0, d.size)
            t.setNotificationMarkerPosition(d.size - 1)
            t.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(track: AudioTrack) { track.release() }
                override fun onPeriodicNotification(track: AudioTrack) {}
            })
            t.play()
        } catch (_: Exception) {}
    }

    /** Har bir sahna boshiga effektni qo'yib, butun video uzunligidagi stereo WAV yaratadi. */
    fun renderTrack(dir: File, durs: List<Long>, sfx: List<Int>, gain: Float = 0.7f): File {
        val file = File(dir, "sfx_${System.currentTimeMillis()}.wav")
        val totalSamples = durs.sum() * SR / 1000
        val events = ArrayList<Pair<Long, ShortArray>>()
        var t = 0L
        for (i in durs.indices) {
            if (sfx[i] > 0) events.add((t * SR / 1000) to pcm(sfx[i]))
            t += durs[i]
        }
        file.outputStream().buffered().use { o ->
            val dataBytes = totalSamples * 4
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt((36 + dataBytes).toInt()); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(2)
            h.putInt(SR); h.putInt(SR * 4); h.putShort(4); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(dataBytes.toInt())
            o.write(h.array())

            val chunk = SR
            val mix = IntArray(chunk)
            val bytes = ByteArray(chunk * 4)
            var pos = 0L
            while (pos < totalSamples) {
                val n = minOf(chunk.toLong(), totalSamples - pos).toInt()
                java.util.Arrays.fill(mix, 0, n, 0)
                for ((st, d) in events) {
                    val s = maxOf(st, pos)
                    val e = minOf(st + d.size, pos + n)
                    var k = s
                    while (k < e) { mix[(k - pos).toInt()] += d[(k - st).toInt()].toInt(); k++ }
                }
                for (k in 0 until n) {
                    val v = (mix[k] * gain).toInt().coerceIn(-32768, 32767)
                    val lo = (v and 0xFF).toByte()
                    val hi = ((v shr 8) and 0xFF).toByte()
                    bytes[k * 4] = lo; bytes[k * 4 + 1] = hi; bytes[k * 4 + 2] = lo; bytes[k * 4 + 3] = hi
                }
                o.write(bytes, 0, n * 4)
                pos += n
            }
        }
        return file
    }
}
