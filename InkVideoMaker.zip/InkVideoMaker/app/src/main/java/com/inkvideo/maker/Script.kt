package com.inkvideo.maker

import kotlin.random.Random

/** Matndagi har bir bo'sh bo'lmagan qator = bitta kadr. */
fun splitLines(text: String): List<String> =
    text.removePrefix("\uFEFF").lines().map { it.trim() }.filter { it.isNotEmpty() }

private val WS = Regex("\\s+")

private fun weight(line: String): Double {
    val words = line.split(WS).count { it.isNotEmpty() }.coerceAtLeast(1)
    val soft = line.count { it == ',' || it == ';' || it == ':' }
    val stops = line.count { it == '.' || it == '?' || it == '!' }
    return words + 0.35 * soft + 0.6 * stops
}

/** Audio uzunligini qatorlarga so'z soni (va tinish belgilari) bo'yicha taqsimlaydi. */
fun splitDurations(lines: List<String>, totalMs: Long): List<Long> {
    val w = lines.map { weight(it) }
    val sum = w.sum()
    val raw = w.map { (it / sum * totalMs).toLong().coerceAtLeast(500L) }.toMutableList()
    val diff = totalMs - raw.sum()
    val k = raw.indices.maxByOrNull { raw[it] } ?: 0
    raw[k] = maxOf(500L, raw[k] + diff)
    return raw
}

data class FxSet(val anim: Int, val trans: Int, val sfx: Int)

// Har bir o'tish turiga mos ovoz effektlari (Sfx.names indekslari)
private val SFX_FOR_TRANS = arrayOf(
    intArrayOf(3),        // Kesish -> klik
    intArrayOf(0, 6),     // Fade -> jim yoki qo'ng'iroq
    intArrayOf(2, 5),     // Zoom zarba -> pop / zarba
    intArrayOf(1, 4),     // O'ngdan sirpanish -> shamol / svish
    intArrayOf(1, 4),     // Chapdan sirpanish
    intArrayOf(1, 4),     // Pastdan sirpanish
    intArrayOf(5, 6),     // Yaltirash -> zarba / qo'ng'iroq
    intArrayOf(5, 3),     // Titrash -> zarba / klik
)

/** Ketma-ket takrorlanmaydigan, har xil animatsiya + o'tish + ovoz tanlaydi. */
fun autoFx(n: Int, seed: Long): List<FxSet> {
    val r = Random(seed)
    var pa = -1
    var pt = -1
    val na = VideoBuilder.ANIM_NAMES.size
    val nt = VideoBuilder.TRANS_NAMES.size
    return List(n) { i ->
        var a = r.nextInt(na)
        while (a == pa) a = r.nextInt(na)
        var t = r.nextInt(nt)
        while (t == pt) t = r.nextInt(nt)
        if (i == 0) t = 1
        pa = a
        pt = t
        val opts = SFX_FOR_TRANS[t]
        FxSet(a, t, if (i == 0) 0 else opts[r.nextInt(opts.size)])
    }
}
