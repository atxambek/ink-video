package com.inkvideo.maker

data class Cue(val startMs: Long, val endMs: Long)

private val TIME = Regex("""(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)""")

private fun ms(h: String, m: String, s: String, f: String): Long =
    h.toLong() * 3_600_000 + m.toLong() * 60_000 + s.toLong() * 1000 + f.padEnd(3, '0').take(3).toLong()

fun parseSrt(text: String): List<Cue> =
    TIME.findAll(text.removePrefix("\uFEFF")).map {
        val g = it.groupValues
        Cue(ms(g[1], g[2], g[3], g[4]), ms(g[5], g[6], g[7], g[8]))
    }.toList().sortedBy { it.startMs }
