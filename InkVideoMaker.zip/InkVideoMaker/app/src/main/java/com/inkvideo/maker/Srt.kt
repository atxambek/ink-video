package com.inkvideo.maker

data class Cue(val startMs: Long, val endMs: Long)

private val TIME = Regex("""(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)""")

private fun ms(h: String, m: String, s: String, f: String): Long =
    h.toLong() * 3_600_000 + m.toLong() * 60_000 + s.toLong() * 1000 + f.padEnd(3, '0').take(3).toLong()

fun parseSrt(text: String): List<Cue> =
    TIME.findAll(text.removePrefix("\uFEFF")).map {
        val g = it.groupValues
        Cue(ms(g[1], g[2], g[3], g[4]), ms(g[5], g[6], g[7], g[8]))
    }.toList().sortedBy { it.startMs }

// "(0:07) text ... (0:12) text ..." formatidagi TurboScribe matnini ham qabul qiladi
private val STAMP = Regex("""\(?(\d{1,2}):(\d{2})(?::(\d{2}))?\)""")

fun parseTimed(text: String): List<Cue> {
    if (text.contains("-->")) return parseSrt(text)
    val starts = STAMP.findAll(text).map { m ->
        val a = m.groupValues[1].toLong()
        val b = m.groupValues[2].toLong()
        val c = m.groupValues[3]
        (if (c.isEmpty()) a * 60 + b else a * 3600 + b * 60 + c.toLong()) * 1000
    }.toList().distinct().sorted()
    return starts.mapIndexed { i, s -> Cue(s, if (i < starts.lastIndex) starts[i + 1] else s + 5000) }
}
