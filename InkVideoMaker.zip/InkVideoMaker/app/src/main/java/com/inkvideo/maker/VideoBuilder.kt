package com.inkvideo.maker

import android.content.ContentValues
import android.content.Context
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import java.io.File

object VideoBuilder {

    fun audioDurationMs(context: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        } finally { r.release() }
    }

    /** Must be called on the main thread. */
    fun build(
        context: Context,
        images: List<Uri>,
        durationsMs: List<Long>,
        audio: Uri,
        width: Int,
        height: Int,
        onProgress: (Int) -> Unit,
        onDone: (String) -> Unit,
        onError: (String) -> Unit,
    ) {
        if (images.isEmpty()) { onError("Rasm yo'q"); return }

        val items = images.indices.map { i ->
            val durMs = maxOf(durationsMs[i], 200L)
            val zoomIn = i % 2 == 0
            val kenBurns = MatrixTransformation { tUs ->
                val p = (tUs / 1000f / durMs).coerceIn(0f, 1f)
                val s = if (zoomIn) 1f + 0.08f * p else 1.08f - 0.08f * p
                Matrix().apply { setScale(s, s) }
            }
            val fit = Presentation.createForWidthAndHeight(width, height, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
            EditedMediaItem.Builder(
                MediaItem.Builder().setUri(images[i]).setImageDurationMs(durMs).build()
            )
                .setDurationUs(durMs * 1000)
                .setFrameRate(30)
                .setEffects(Effects(emptyList(), listOf(fit, kenBurns)))
                .build()
        }

        val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(audio)).build()
        val composition = Composition.Builder(
            listOf(EditedMediaItemSequence(items), EditedMediaItemSequence(listOf(audioItem)))
        ).build()

        val out = File(context.cacheDir, "out_${System.currentTimeMillis()}.mp4")
        val handler = Handler(Looper.getMainLooper())
        lateinit var transformer: Transformer
        val holder = ProgressHolder()
        var running = true

        val poll = object : Runnable {
            override fun run() {
                if (!running) return
                if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) onProgress(holder.progress)
                handler.postDelayed(this, 500)
            }
        }

        transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, r: ExportResult) {
                    running = false
                    try { onDone(saveToMovies(context, out)) } catch (e: Exception) { onError(e.message ?: "Saqlashda xato") }
                }
                override fun onError(c: Composition, r: ExportResult, e: ExportException) {
                    running = false
                    onError(e.message ?: "Eksport xatosi")
                }
            })
            .build()

        transformer.start(composition, out.absolutePath)
        handler.post(poll)
    }

    private fun saveToMovies(context: Context, file: File): String {
        val name = "ink_video_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/InkVideoMaker")
        }
        val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("MediaStore xatosi")
        context.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        file.delete()
        return "Movies/InkVideoMaker/$name"
    }
}
