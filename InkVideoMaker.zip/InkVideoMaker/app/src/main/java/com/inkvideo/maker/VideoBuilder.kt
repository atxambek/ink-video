package com.inkvideo.maker

import android.content.ContentValues
import android.content.Context
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Effect
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

object VideoBuilder {

    fun audioDurationMs(context: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        } finally { r.release() }
    }

    val ANIM_NAMES = listOf(
        "Zoom ichkari", "Zoom tashqari", "Chapga surish", "O'ngga surish", "Tepaga surish",
        "Pastga surish", "Zoom chap-yuqori", "Zoom o'ng-past", "Burchakdan chiqish", "Diagonal siljish"
    )
    val TRANS_NAMES = listOf(
        "Kesish", "Fade", "Zoom zarba", "O'ngdan sirpanish", "Chapdan sirpanish",
        "Pastdan sirpanish", "Yaltirash", "Titrash"
    )

    // [scale0, scale1, x0, x1, y0, y1]  (x, y: -1..1 — ruxsat etilgan siljish ulushi)
    private val ANIM = arrayOf(
        floatArrayOf(1.00f, 1.14f, 0f, 0f, 0f, 0f),
        floatArrayOf(1.14f, 1.00f, 0f, 0f, 0f, 0f),
        floatArrayOf(1.14f, 1.14f, 1f, -1f, 0f, 0f),
        floatArrayOf(1.14f, 1.14f, -1f, 1f, 0f, 0f),
        floatArrayOf(1.14f, 1.14f, 0f, 0f, -1f, 1f),
        floatArrayOf(1.14f, 1.14f, 0f, 0f, 1f, -1f),
        floatArrayOf(1.00f, 1.16f, 0f, -1f, 0f, 1f),
        floatArrayOf(1.00f, 1.16f, 0f, 1f, 0f, -1f),
        floatArrayOf(1.16f, 1.00f, 1f, 1f, 1f, 1f),
        floatArrayOf(1.08f, 1.12f, -1f, 1f, -1f, 1f),
    )

    /** s = masshtab, tx/ty = siljish (NDC), b = yorqinlik (0 = qora, 1 = normal, >1 = yaltirash). */
    class Fx(val s: Float, val tx: Float, val ty: Float, val b: Float)

    /** Sahna ichidagi tMs vaqtidagi animatsiya + kirish (o'tish) effekti. Preview va eksport bir xil ishlatadi. */
    fun fx(anim: Int, trans: Int, tMs: Long, durMs: Long): Fx {
        val p = (tMs.toFloat() / durMs).coerceIn(0f, 1f)
        val e = p * p * (3f - 2f * p)
        val a = ANIM[anim.mod(ANIM.size)]
        var s = a[0] + (a[1] - a[0]) * e
        val x = a[2] + (a[3] - a[2]) * e
        val y = a[4] + (a[5] - a[4]) * e
        var tx = x * (s - 1f) * 0.95f
        var ty = y * (s - 1f) * 0.95f
        var b = 1f
        val enter = maxOf(1L, minOf(400L, durMs / 2))
        val q = (tMs.toFloat() / enter).coerceIn(0f, 1f)
        val eo = 1f - (1f - q) * (1f - q) * (1f - q)
        when (trans) {
            1 -> b = q
            2 -> { s *= 1f + 0.3f * (1f - eo); b = minOf(1f, q * 2f + 0.2f) }
            3 -> tx += 2f * (1f - eo)
            4 -> tx -= 2f * (1f - eo)
            5 -> ty -= 2f * (1f - eo)
            6 -> b = 1f + 2f * (1f - eo)
            7 -> { s *= 1.06f; tx += 0.05f * (1f - q) * sin(q * 40f); ty += 0.03f * (1f - q) * cos(q * 47f) }
        }
        return Fx(s, tx, ty, b)
    }

    /** Must be called on the main thread. */
    fun build(
        context: Context,
        scenes: List<Scene>,
        sfxTrack: File?,
        audio: Uri,
        width: Int,
        height: Int,
        bitrate: Int,
        onProgress: (Int) -> Unit,
        onDone: (String) -> Unit,
        onError: (String) -> Unit,
    ) {
        if (scenes.isEmpty()) { onError("Rasm yo'q"); return }

        val items = scenes.map { sc ->
            val durMs = maxOf(sc.durMs, 200L)
            val motionFx = MatrixTransformation { tUs ->
                val f = fx(sc.anim, sc.trans, tUs / 1000, durMs)
                Matrix().apply { setScale(f.s, f.s); postTranslate(f.tx, f.ty) }
            }
            val brightFx = RgbMatrix { tUs, _ ->
                val k = fx(sc.anim, sc.trans, tUs / 1000, durMs).b
                floatArrayOf(k, 0f, 0f, 0f, 0f, k, 0f, 0f, 0f, 0f, k, 0f, 0f, 0f, 0f, 1f)
            }
            val fit = Presentation.createForWidthAndHeight(width, height, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
            val vfx = mutableListOf<Effect>(fit, motionFx)
            if (sc.trans == 1 || sc.trans == 2 || sc.trans == 6) vfx.add(brightFx)
            EditedMediaItem.Builder(
                MediaItem.Builder().setUri(sc.uri).setImageDurationMs(durMs).build()
            )
                .setDurationUs(durMs * 1000)
                .setFrameRate(30)
                .setEffects(Effects(emptyList(), vfx))
                .build()
        }

        val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(audio)).build()
        val sequences = mutableListOf(EditedMediaItemSequence(items), EditedMediaItemSequence(listOf(audioItem)))
        if (sfxTrack != null) {
            val sfxItem = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(sfxTrack))).build()
            sequences.add(EditedMediaItemSequence(listOf(sfxItem)))
        }
        val composition = Composition.Builder(sequences).build()

        val encoderFactory = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
            .build()

        val out = File(context.cacheDir, "out_${System.currentTimeMillis()}.mp4")
        val handler = Handler(Looper.getMainLooper())
        lateinit var transformer: Transformer
        val holder = ProgressHolder()
        var running = true

        val poll = object : Runnable {
            override fun run() {
                if (!running) return
                if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) onProgress(holder.progress)
                handler.postDelayed(this, 500)
            }
        }

        transformer = Transformer.Builder(context)
            .setEncoderFactory(encoderFactory)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, r: ExportResult) {
                    running = false
                    sfxTrack?.delete()
                    try { onDone(saveToMovies(context, out)) } catch (e: Exception) { onError(e.message ?: "Saqlashda xato") }
                }
                override fun onError(c: Composition, r: ExportResult, e: ExportException) {
                    running = false
                    sfxTrack?.delete()
                    onError(e.message ?: "Eksport xatosi")
                }
            })
            .build()

        transformer.start(composition, out.absolutePath)
        handler.post(poll)
    }

    private fun saveToMovies(context: Context, file: File): String {
        val name = "ink_video_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/InkVideoMaker")
        }
        val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("MediaStore xatosi")
        context.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        file.delete()
        return "Movies/InkVideoMaker/$name"
    }
}
