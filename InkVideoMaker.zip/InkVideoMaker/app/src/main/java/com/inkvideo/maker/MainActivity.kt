package com.inkvideo.maker

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

data class Scene(val uri: Uri, val durMs: Long)

private val Bg = Color(0xFF000000)
private val Panel = Color(0xFF151515)
private val Accent = Color(0xFF20E3D2)
private val Dim = Color(0xFF9A9A9A)
private const val DP_PER_SEC = 40f

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) {
                Surface(color = Bg, modifier = Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private fun nameOf(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    } ?: uri.lastPathSegment.orEmpty()

private val NUM = Regex("""\d+|\D+""")
private fun naturalKey(s: String) = NUM.findAll(s.lowercase()).joinToString("|") {
    if (it.value[0].isDigit()) it.value.padStart(8, '0') else it.value
}

private fun loadBitmap(ctx: Context, uri: Uri, max: Int = 480): ImageBitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / s > max) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }?.asImageBitmap()
} catch (e: Exception) { null }

private fun fmt(ms: Long): String {
    val t = ms / 100
    return "%d:%02d.%d".format(t / 600, (t / 10) % 60, t % 10)
}

@Composable
fun App() {
    var project by remember { mutableStateOf<Pair<List<Scene>, Uri>?>(null) }
    val p = project
    if (p == null) ImportScreen { s, a -> project = s to a } else Editor(p.first, p.second)
}

@Composable
fun ImportScreen(onStart: (List<Scene>, Uri) -> Unit) {
    val ctx = LocalContext.current
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var audio by remember { mutableStateOf<Uri?>(null) }
    var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }

    val pickImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l ->
        images = l.sortedBy { naturalKey(nameOf(ctx, it)) }
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { audio = it }
    val pickSrt = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) cues = parseSrt(ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText().orEmpty())
    }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("Ink Video Maker", fontSize = 26.sp)
        Text("Yangi loyiha", color = Dim)
        Button(onClick = { pickImages.launch("image/*") }, Modifier.fillMaxWidth()) { Text("🖼  Rasmlar (${images.size})") }
        Button(onClick = { pickAudio.launch(arrayOf("audio/*")) }, Modifier.fillMaxWidth()) {
            Text(if (audio == null) "🎙  Voiceover audio" else "🎙  Audio ✓")
        }
        Button(onClick = { pickSrt.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("📝  SRT (${cues.size} ta sahna)") }
        if (images.isNotEmpty() && cues.isNotEmpty() && images.size != cues.size)
            Text("Diqqat: ${images.size} rasm, ${cues.size} sahna. Kichigi olinadi.", color = Color(0xFFFF6B6B))
        Spacer(Modifier.weight(1f))
        Button(
            onClick = {
                val a = audio!!
                val n = minOf(images.size, cues.size)
                val total = maxOf(VideoBuilder.audioDurationMs(ctx, a), cues.last().endMs)
                val starts = List(n) { if (it == 0) 0L else cues[it].startMs }
                val scenes = (0 until n).map { i ->
                    Scene(images[i], maxOf((if (i < n - 1) starts[i + 1] else total) - starts[i], 500L))
                }
                onStart(scenes, a)
            },
            Modifier.fillMaxWidth().height(52.dp),
            enabled = images.isNotEmpty() && audio != null && cues.isNotEmpty()
        ) { Text("Tahrirlashni boshlash", color = Color.Black) }
    }
}

@Composable
fun ToolBtn(icon: String, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 20.sp)
        Text(label, fontSize = 11.sp, color = Dim)
    }
}

@Composable
fun Editor(initial: List<Scene>, audio: Uri) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val scenes = remember { mutableStateListOf<Scene>().apply { addAll(initial) } }
    val bitmaps = remember { mutableStateMapOf<Uri, ImageBitmap>() }
    val mp = remember { MediaPlayer().apply { setDataSource(ctx, audio); prepare() } }
    DisposableEffect(Unit) { onDispose { mp.release() } }

    var pos by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var vertical by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }
    var replaceIdx by remember { mutableIntStateOf(0) }
    val scroll = rememberScrollState()
    val pxPerMs = with(density) { DP_PER_SEC.dp.toPx() } / 1000f
    val total = scenes.sumOf { it.durMs }

    fun startOf(i: Int) = scenes.take(i).sumOf { it.durMs }
    fun indexAt(p: Long): Int {
        var acc = 0L
        scenes.forEachIndexed { i, s -> acc += s.durMs; if (p < acc) return i }
        return scenes.lastIndex
    }
    fun seekAndScroll(ms: Long) {
        val c = ms.coerceIn(0L, total)
        pos = c
        mp.seekTo(c.toInt())
        scope.launch { scroll.scrollTo((c * pxPerMs).toInt()) }
    }

    val pickOne = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null && replaceIdx in scenes.indices) scenes[replaceIdx] = scenes[replaceIdx].copy(uri = u)
    }

    LaunchedEffect(scenes.map { it.uri }) {
        scenes.forEach { s ->
            if (s.uri !in bitmaps) {
                val b = withContext(Dispatchers.IO) { loadBitmap(ctx, s.uri) }
                if (b != null) bitmaps[s.uri] = b
            }
        }
    }
    LaunchedEffect(scroll.value) {
        if (!playing) {
            val p = (scroll.value / pxPerMs).toLong().coerceIn(0L, total)
            if (abs(p - pos) > 20) { pos = p; mp.seekTo(p.toInt()) }
        }
    }
    LaunchedEffect(Unit) {
        scroll.interactionSource.interactions.collect {
            if (it is DragInteraction.Start && playing) { playing = false; mp.pause() }
        }
    }
    LaunchedEffect(playing) {
        if (playing) {
            if (pos >= total - 50) pos = 0
            mp.seekTo(pos.toInt()); mp.start()
            while (playing) {
                pos = mp.currentPosition.toLong().coerceAtMost(total)
                scroll.scrollTo((pos * pxPerMs).toInt())
                if (pos >= total || !mp.isPlaying) playing = false
                delay(30)
            }
            mp.pause()
        }
    }

    val cur = indexAt(pos)
    val sc = scenes.getOrNull(cur)

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Ink Video Maker", Modifier.weight(1f), fontSize = 16.sp)
            Button(
                enabled = !exporting,
                onClick = {
                    playing = false; mp.pause()
                    exporting = true; progress = 0; status = "Eksport qilinmoqda..."
                    VideoBuilder.build(
                        ctx, scenes.map { it.uri }, scenes.map { it.durMs }, audio,
                        if (vertical) 720 else 1280, if (vertical) 1280 else 720,
                        onProgress = { progress = it },
                        onDone = { exporting = false; progress = 100; status = "Tayyor: $it" },
                        onError = { exporting = false; status = "Xato: $it" }
                    )
                }
            ) { Text("Eksport", color = Color.Black) }
        }

        // Preview
        Box(Modifier.weight(1f).fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.fillMaxHeight()
                    .aspectRatio(if (vertical) 9f / 16 else 16f / 9, matchHeightConstraintsFirst = true)
                    .clip(RectangleShape).background(Color(0xFF111111))
            ) {
                val bmp = sc?.let { bitmaps[it.uri] }
                if (bmp != null && sc != null) {
                    val p = ((pos - startOf(cur)).toFloat() / sc.durMs).coerceIn(0f, 1f)
                    val z = if (cur % 2 == 0) 1f + 0.08f * p else 1.08f - 0.08f * p
                    Image(bmp, null, Modifier.fillMaxSize().graphicsLayer(scaleX = z, scaleY = z), contentScale = ContentScale.Crop)
                }
            }
        }

        // Transport
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (playing) "⏸" else "▶", fontSize = 26.sp, modifier = Modifier.clickable { playing = !playing }.padding(8.dp))
            Slider(
                value = pos.toFloat(),
                onValueChange = { seekAndScroll(it.toLong()) },
                valueRange = 0f..maxOf(total, 1L).toFloat(),
                modifier = Modifier.weight(1f)
            )
            Text("${fmt(pos)} / ${fmt(total)}", fontSize = 11.sp, color = Dim)
        }

        // Timeline
        BoxWithConstraints(Modifier.fillMaxWidth().height(86.dp).background(Panel)) {
            val half = maxWidth / 2
            Row(
                Modifier.horizontalScroll(scroll).fillMaxHeight().padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(Modifier.width(half))
                scenes.forEachIndexed { i, s ->
                    val shape = RoundedCornerShape(6.dp)
                    Box(
                        Modifier.width((s.durMs / 1000f * DP_PER_SEC).dp).fillMaxHeight()
                            .padding(horizontal = 1.dp).clip(shape).background(Color(0xFF2A2A2A))
                            .then(if (i == cur) Modifier.border(2.dp, Accent, shape) else Modifier)
                            .clickable { seekAndScroll(startOf(i)) }
                    ) {
                        bitmaps[s.uri]?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        Text("${i + 1}", fontSize = 10.sp, modifier = Modifier.background(Color(0x99000000)).padding(horizontal = 4.dp))
                    }
                }
                Spacer(Modifier.width(half))
            }
            Box(Modifier.align(Alignment.Center).width(2.dp).fillMaxHeight().background(Color.White))
        }

        if (exporting) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
        if (status.isNotEmpty()) Text(status, Modifier.padding(horizontal = 12.dp, vertical = 4.dp), fontSize = 12.sp, color = Accent)

        // Toolbar
        Row(Modifier.fillMaxWidth().background(Panel).horizontalScroll(rememberScrollState())) {
            ToolBtn("🖼", "Rasm almashtir") { replaceIdx = cur; pickOne.launch("image/*") }
            ToolBtn("➖", "Qisqartir 0.5s") {
                if (sc != null) scenes[cur] = sc.copy(durMs = maxOf(500L, sc.durMs - 500))
            }
            ToolBtn("➕", "Uzaytir 0.5s") {
                if (sc != null) scenes[cur] = sc.copy(durMs = sc.durMs + 500)
            }
            ToolBtn("🗑", "O'chirish") {
                if (scenes.size > 1) {
                    scenes.removeAt(cur)
                    seekAndScroll(startOf(minOf(cur, scenes.lastIndex)))
                }
            }
            ToolBtn("📐", if (vertical) "9:16" else "16:9") { vertical = !vertical }
        }
    }
}
