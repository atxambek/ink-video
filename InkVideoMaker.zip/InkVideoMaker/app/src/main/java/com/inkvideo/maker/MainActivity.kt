package com.inkvideo.maker

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

data class Scene(val uri: Uri, val durMs: Long)

private val Bg = Color(0xFF000000)
private val Card = Color(0xFF161616)
private val Panel = Color(0xFF0B0B0B)
private val Accent = Color(0xFF20E3D2)
private val Accent2 = Color(0xFF5B8CFF)
private val Dim = Color(0xFF8E8E93)
private val GradBrush = Brush.horizontalGradient(listOf(Accent, Accent2))
private const val DP_PER_SEC = 40f

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Bg)) {
                Surface(color = Bg, modifier = Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private fun nameOf(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    } ?: uri.lastPathSegment.orEmpty()

private val NUM = Regex("""\d+|\D+""")
private fun naturalKey(s: String) = NUM.findAll(s.lowercase()).joinToString("|") {
    if (it.value[0].isDigit()) it.value.padStart(8, '0') else it.value
}

private fun loadBitmap(ctx: Context, uri: Uri, max: Int = 480): ImageBitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / s > max) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }?.asImageBitmap()
} catch (e: Exception) { null }

private fun extractZip(ctx: Context, zip: Uri): List<Uri> {
    val dir = File(ctx.cacheDir, "project_images").apply { deleteRecursively(); mkdirs() }
    val found = mutableListOf<Pair<String, File>>()
    ctx.contentResolver.openInputStream(zip)!!.use { raw ->
        ZipInputStream(raw.buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val base = e.name.substringAfterLast('/')
                val low = base.lowercase()
                val ok = !e.isDirectory && !e.name.contains("__MACOSX") && !base.startsWith(".") &&
                    (low.endsWith(".jpg") || low.endsWith(".jpeg") || low.endsWith(".png") || low.endsWith(".webp"))
                if (ok) {
                    val f = File(dir, "tmp_${found.size}")
                    f.outputStream().use { zis.copyTo(it) }
                    found.add(base to f)
                }
                zis.closeEntry()
                e = zis.nextEntry
            }
        }
    }
    return found.sortedBy { naturalKey(it.first) }.mapIndexed { i, (base, f) ->
        val nf = File(dir, "%04d_%s".format(i + 1, base))
        f.renameTo(nf)
        Uri.fromFile(nf)
    }
}

private fun clock(ms: Long): String {
    val t = ms / 1000
    return "%02d:%02d".format(t / 60, t % 60)
}

@Composable
fun App() {
    var project by remember { mutableStateOf<Pair<List<Scene>, Uri>?>(null) }
    val p = project
    if (p == null) ImportScreen { s, a -> project = s to a }
    else Editor(p.first, p.second) { project = null }
}

// ---------------------------------------------------------------- Import

@Composable
fun ImportCard(emoji: String, title: String, sub: String, done: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Accent.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) { Text(emoji, fontSize = 22.sp) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, fontSize = 12.sp, color = Dim)
        }
        if (done) Icon(Icons.Filled.CheckCircle, null, tint = Accent)
        else Icon(Icons.Filled.KeyboardArrowRight, null, tint = Dim)
    }
}

@Composable
fun ImportScreen(onStart: (List<Scene>, Uri) -> Unit) {
    val ctx = LocalContext.current
    var picked by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var byName by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    val images = remember(picked, byName) {
        if (byName) picked.sortedBy { naturalKey(nameOf(ctx, it)) } else picked
    }
    var audio by remember { mutableStateOf<Uri?>(null) }
    var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }

    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    var zipError by remember { mutableStateOf("") }
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            loading = true; zipError = ""
            scope.launch {
                val files = withContext(Dispatchers.IO) { runCatching { extractZip(ctx, u) }.getOrDefault(emptyList()) }
                loading = false
                if (files.isEmpty()) zipError = "ZIP ichida rasm topilmadi" else { picked = files; byName = false }
            }
        }
    }
    var showPaste by remember { mutableStateOf(false) }
    var pasteText by remember { mutableStateOf("") }
    var pasteError by remember { mutableStateOf("") }

    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { audio = it }
    val pickSrt = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val c = parseTimed(ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText().orEmpty())
            if (c.isNotEmpty()) { cues = c; showPaste = false } else pasteError = "Faylda vaqtlar topilmadi"
        }
    }

    if (showPicker) {
        PickerScreen(onDone = { picked = it; byName = false; showPicker = false }, onCancel = { showPicker = false })
        return
    }

    val ready = images.isNotEmpty() && audio != null && cues.isNotEmpty()

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        if (showPaste) {
            AlertDialog(
                onDismissRequest = { showPaste = false },
                containerColor = Card,
                title = { Text("Vaqtli matn") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = pasteText, onValueChange = { pasteText = it; pasteError = "" },
                            modifier = Modifier.fillMaxWidth(), minLines = 6, maxLines = 8,
                            placeholder = { Text("(0:00) Imagine this... (0:07) ...", color = Dim) }
                        )
                        if (pasteError.isNotEmpty()) Text(pasteError, color = Color(0xFFFF6B6B), fontSize = 12.sp)
                        TextButton(onClick = { pickSrt.launch(arrayOf("*/*")) }) { Text("Fayldan tanlash (.txt yoki .srt)", color = Accent) }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val c = parseTimed(pasteText)
                        if (c.isEmpty()) pasteError = "Vaqtlar topilmadi. Masalan: (0:07)" else { cues = c; showPaste = false }
                    }) { Text("Qo'llash", color = Accent) }
                },
                dismissButton = { TextButton(onClick = { showPaste = false }) { Text("Bekor") } }
            )
        }
        Spacer(Modifier.height(16.dp))
        Text("Ink Video Maker", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Yangi loyiha yarating", color = Dim, fontSize = 14.sp)
        Spacer(Modifier.height(28.dp))

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ImportCard(
                "🗜", "Rasmlar (ZIP fayl)",
                when { loading -> "Ochilmoqda..."; images.isEmpty() -> "Tartib bilan yig'ilgan ZIP"; else -> "${images.size} ta rasm tayyor" },
                images.isNotEmpty()
            ) { pickZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }
            ImportCard("🖼", "Rasmlar (galereyadan)", "Ketma-ket raqamlab tanlang", false) { showPicker = true }
            ImportCard("🎙", "Voiceover audio", if (audio == null) "MP3 yoki WAV fayl" else "Audio tanlandi", audio != null) { pickAudio.launch(arrayOf("audio/*")) }
            ImportCard("📝", "Vaqtli matn (TurboScribe)", if (cues.isEmpty()) "Matnni joylang yoki fayl tanlang" else "${cues.size} ta sahna", cues.isNotEmpty()) { showPaste = true }
        }

        if (zipError.isNotEmpty()) Text(zipError, color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        if (images.size > 1) {
            Spacer(Modifier.height(12.dp))
            Text(
                if (byName) "Tartib: fayl nomi bo'yicha  ·  o'zgartirish" else "Tartib: o'zim tanlagan  ·  o'zgartirish",
                color = Accent, fontSize = 13.sp,
                modifier = Modifier.clickable { byName = !byName }.padding(4.dp)
            )
        }
        if (images.isNotEmpty() && cues.isNotEmpty() && images.size != cues.size) {
            Spacer(Modifier.height(8.dp))
            Text("Diqqat: ${images.size} rasm, ${cues.size} sahna. Kichigi olinadi.", color = Color(0xFFFF6B6B), fontSize = 13.sp)
        }

        Spacer(Modifier.weight(1f))
        Box(
            Modifier.fillMaxWidth().height(54.dp).alpha(if (ready) 1f else 0.35f)
                .clip(RoundedCornerShape(27.dp)).background(GradBrush)
                .clickable(enabled = ready) {
                    val a = audio!!
                    val n = minOf(images.size, cues.size)
                    val total = maxOf(VideoBuilder.audioDurationMs(ctx, a), cues.last().endMs)
                    val starts = List(n) { if (it == 0) 0L else cues[it].startMs }
                    val scenes = (0 until n).map { i ->
                        Scene(images[i], maxOf((if (i < n - 1) starts[i + 1] else total) - starts[i], 500L))
                    }
                    onStart(scenes, a)
                },
            contentAlignment = Alignment.Center
        ) { Text("Tahrirlashni boshlash", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    }
}

// ---------------------------------------------------------------- Editor

@Composable
fun ToolBtn(label: String, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Column(
        Modifier.widthIn(min = 68.dp).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) { icon() }
        Spacer(Modifier.height(3.dp))
        Text(label, fontSize = 10.sp, color = Color(0xFFCCCCCC))
    }
}

@Composable
fun Glyph(t: String) = Text(t, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)

@Composable
fun PauseGlyph(color: Color, size: Dp = 18.dp) {
    Row(horizontalArrangement = Arrangement.spacedBy(size / 4)) {
        repeat(2) { Box(Modifier.width(size / 3).height(size).background(color, RoundedCornerShape(2.dp))) }
    }
}

@Composable
fun Editor(initial: List<Scene>, audio: Uri, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val scenes = remember { mutableStateListOf<Scene>().apply { addAll(initial) } }
    val bitmaps = remember { mutableStateMapOf<Uri, ImageBitmap>() }
    val mp = remember { MediaPlayer().apply { setDataSource(ctx, audio); prepare() } }
    DisposableEffect(Unit) { onDispose { mp.release() } }

    var pos by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var vertical by remember { mutableStateOf(false) }
    var hd by remember { mutableStateOf(true) }
    var exporting by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }
    var replaceIdx by remember { mutableIntStateOf(0) }
    val scroll = rememberScrollState()
    val pxPerMs = with(density) { DP_PER_SEC.dp.toPx() } / 1000f
    val total = scenes.sumOf { it.durMs }

    fun startOf(i: Int) = scenes.take(i).sumOf { it.durMs }
    fun indexAt(p: Long): Int {
        var acc = 0L
        scenes.forEachIndexed { i, s -> acc += s.durMs; if (p < acc) return i }
        return scenes.lastIndex
    }
    fun seekAndScroll(ms: Long) {
        val c = ms.coerceIn(0L, total)
        pos = c
        mp.seekTo(c.toInt())
        scope.launch { scroll.scrollTo((c * pxPerMs).toInt()) }
    }

    val pickOne = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null && replaceIdx in scenes.indices) scenes[replaceIdx] = scenes[replaceIdx].copy(uri = u)
    }

    LaunchedEffect(scenes.map { it.uri }) {
        scenes.forEach { s ->
            if (s.uri !in bitmaps) {
                val b = withContext(Dispatchers.IO) { loadBitmap(ctx, s.uri) }
                if (b != null) bitmaps[s.uri] = b
            }
        }
    }
    LaunchedEffect(scroll.value) {
        if (!playing) {
            val p = (scroll.value / pxPerMs).toLong().coerceIn(0L, total)
            if (abs(p - pos) > 20) { pos = p; mp.seekTo(p.toInt()) }
        }
    }
    LaunchedEffect(Unit) {
        scroll.interactionSource.interactions.collect {
            if (it is DragInteraction.Start && playing) { playing = false; mp.pause() }
        }
    }
    LaunchedEffect(playing) {
        if (playing) {
            if (pos >= total - 50) pos = 0
            mp.seekTo(pos.toInt()); mp.start()
            while (playing) {
                pos = mp.currentPosition.toLong().coerceAtMost(total)
                scroll.scrollTo((pos * pxPerMs).toInt())
                if (pos >= total || !mp.isPlaying) playing = false
                delay(30)
            }
            mp.pause()
        }
    }

    val cur = indexAt(pos)
    val sc = scenes.getOrNull(cur)

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {

        // ---- Top bar
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(CircleShape).clickable { playing = false; mp.pause(); onBack() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Close, null, tint = Color.White)
            }
            Spacer(Modifier.weight(1f))
            Text(
                (if (hd) "1080p" else "720p") + (if (vertical) " · 9:16" else " · 16:9"), fontSize = 12.sp, color = Color(0xFFDDDDDD),
                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Card)
                    .clickable { hd = !hd }.padding(horizontal = 12.dp, vertical = 7.dp)
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.clip(RoundedCornerShape(20.dp)).background(GradBrush).alpha(if (exporting) 0.4f else 1f)
                    .clickable(enabled = !exporting) {
                        playing = false; mp.pause()
                        exporting = true; showExport = true; progress = 0; status = "Video yig'ilmoqda..."
                        VideoBuilder.build(
                            ctx, scenes.map { it.uri }, scenes.map { it.durMs }, audio,
                            if (vertical) (if (hd) 1080 else 720) else (if (hd) 1920 else 1280),
                            if (vertical) (if (hd) 1920 else 1280) else (if (hd) 1080 else 720),
                            if (hd) 12_000_000 else 6_000_000,
                            onProgress = { progress = it },
                            onDone = { exporting = false; progress = 100; status = "Tayyor! Galereya → Movies/InkVideoMaker" },
                            onError = { exporting = false; status = "Xato: $it" }
                        )
                    }
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) { Text("Eksport", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        }

        // ---- Preview
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.fillMaxHeight()
                    .aspectRatio(if (vertical) 9f / 16 else 16f / 9, matchHeightConstraintsFirst = true)
                    .clip(RoundedCornerShape(10.dp)).background(Color(0xFF111111))
            ) {
                val bmp = sc?.let { bitmaps[it.uri] }
                if (bmp != null && sc != null) {
                    val p = ((pos - startOf(cur)).toFloat() / sc.durMs).coerceIn(0f, 1f)
                    val m = VideoBuilder.motion(cur, p)
                    Image(
                        bmp, null,
                        Modifier.fillMaxSize().graphicsLayer {
                            scaleX = m[0]; scaleY = m[0]
                            translationX = m[1] * size.width / 2f
                            translationY = -m[2] * size.height / 2f
                        },
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }

        // ---- Transport
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                Row {
                    Text(clock(pos), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(" / ${clock(total)}", fontSize = 13.sp, color = Dim)
                }
            }
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color.White).clickable { playing = !playing },
                contentAlignment = Alignment.Center
            ) {
                if (playing) PauseGlyph(Color.Black) else Icon(Icons.Filled.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(28.dp))
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                Text("${cur + 1} / ${scenes.size}", fontSize = 13.sp, color = Dim)
            }
        }

        // ---- Timeline
        val totalDp = (total / 1000f * DP_PER_SEC).dp
        BoxWithConstraints(Modifier.fillMaxWidth().height(138.dp).background(Panel)) {
            val half = maxWidth / 2
            Row(Modifier.horizontalScroll(scroll).fillMaxHeight()) {
                Spacer(Modifier.width(half))
                Column(Modifier.width(totalDp).fillMaxHeight().padding(vertical = 6.dp)) {
                    // ruler
                    Box(Modifier.fillMaxWidth().height(20.dp)) {
                        Canvas(Modifier.fillMaxSize()) {
                            val secs = (total / 1000).toInt()
                            val pxSec = DP_PER_SEC.dp.toPx()
                            for (t in 0..secs) {
                                val x = t * pxSec
                                val major = t % 5 == 0
                                drawLine(
                                    Color(0xFF555555), Offset(x, if (major) 8.dp.toPx() else 13.dp.toPx()),
                                    Offset(x, 19.dp.toPx()), 1.dp.toPx()
                                )
                            }
                        }
                        for (t in 0..(total / 1000).toInt() step 5) {
                            Text(
                                "%d:%02d".format(t / 60, t % 60), fontSize = 9.sp, color = Color(0xFF888888),
                                modifier = Modifier.offset(x = (t * DP_PER_SEC).dp + 3.dp, y = (-1).dp)
                            )
                        }
                    }
                    // video track
                    Row(Modifier.fillMaxWidth().height(60.dp)) {
                        scenes.forEachIndexed { i, s ->
                            val shape = RoundedCornerShape(7.dp)
                            Box(
                                Modifier.width((s.durMs / 1000f * DP_PER_SEC).dp).fillMaxHeight()
                                    .padding(horizontal = 1.dp).clip(shape).background(Color(0xFF2A2A2A))
                                    .then(if (i == cur) Modifier.border(2.dp, Color.White, shape) else Modifier)
                                    .clickable { seekAndScroll(startOf(i)) }
                            ) {
                                bitmaps[s.uri]?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                                Text(
                                    "%.1fs".format(s.durMs / 1000f), fontSize = 9.sp,
                                    modifier = Modifier.align(Alignment.BottomStart).padding(3.dp)
                                        .clip(RoundedCornerShape(4.dp)).background(Color(0xAA000000)).padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    // audio track
                    Box(Modifier.fillMaxWidth().height(30.dp).clip(RoundedCornerShape(7.dp)).background(Color(0xFF0E5D57))) {
                        Canvas(Modifier.fillMaxSize()) {
                            var x = 0f
                            val step = 3.dp.toPx()
                            while (x < size.width) {
                                val h = (0.25f + 0.75f * abs(sin(x * 0.011f) * cos(x * 0.0037f + 1f))) * size.height * 0.8f
                                drawLine(Color(0x88FFFFFF), Offset(x, (size.height - h) / 2), Offset(x, (size.height + h) / 2), 1.5.dp.toPx())
                                x += step
                            }
                        }
                        Text("Voiceover", fontSize = 10.sp, color = Color.White, modifier = Modifier.padding(6.dp))
                    }
                }
                Spacer(Modifier.width(half))
            }
            // playhead
            Box(Modifier.align(Alignment.Center).width(2.dp).fillMaxHeight().background(Color.White))
            Box(Modifier.align(Alignment.TopCenter).offset(y = 2.dp).size(9.dp).clip(CircleShape).background(Color.White))
        }

        Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF222222)))

        // ---- Toolbar
        Row(Modifier.fillMaxWidth().background(Bg).horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp)) {
            ToolBtn("Rasm", { replaceIdx = cur; pickOne.launch("image/*") }) { Icon(Icons.Filled.Refresh, null, tint = Color.White) }
            ToolBtn("Oldinga", {
                if (cur > 0) {
                    val a = scenes[cur]; val b = scenes[cur - 1]
                    scenes[cur] = a.copy(uri = b.uri); scenes[cur - 1] = b.copy(uri = a.uri)
                    seekAndScroll(startOf(cur - 1))
                }
            }) { Icon(Icons.Filled.KeyboardArrowLeft, null, tint = Color.White) }
            ToolBtn("Orqaga", {
                if (cur < scenes.lastIndex) {
                    val a = scenes[cur]; val b = scenes[cur + 1]
                    scenes[cur] = a.copy(uri = b.uri); scenes[cur + 1] = b.copy(uri = a.uri)
                    seekAndScroll(startOf(cur + 1))
                }
            }) { Icon(Icons.Filled.KeyboardArrowRight, null, tint = Color.White) }
            ToolBtn("Qisqartir", {
                if (sc != null) scenes[cur] = sc.copy(durMs = maxOf(500L, sc.durMs - 500))
            }) { Glyph("−.5") }
            ToolBtn("Uzaytir", {
                if (sc != null) scenes[cur] = sc.copy(durMs = sc.durMs + 500)
            }) { Glyph("+.5") }
            ToolBtn("O'chirish", {
                if (scenes.size > 1) {
                    scenes.removeAt(cur)
                    seekAndScroll(startOf(minOf(cur, scenes.lastIndex)))
                }
            }) { Icon(Icons.Filled.Delete, null, tint = Color.White) }
            ToolBtn("Format", { vertical = !vertical }) {
                Text(
                    if (vertical) "9:16" else "16:9", fontSize = 10.sp, color = Color.White,
                    modifier = Modifier.border(1.dp, Color.White, RoundedCornerShape(4.dp)).padding(horizontal = 3.dp, vertical = 2.dp)
                )
            }
        }
    }

    if (showExport) {
        AlertDialog(
            onDismissRequest = { if (!exporting) showExport = false },
            containerColor = Card,
            title = { Text(if (exporting) "Eksport qilinmoqda" else "Eksport") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                    Text("$progress%  ·  $status", fontSize = 13.sp, color = Dim)
                }
            },
            confirmButton = {
                TextButton(enabled = !exporting, onClick = { showExport = false }) { Text("OK", color = Accent) }
            }
        )
    }
}

private data class Pic(val uri: Uri, val date: Long)

@Composable
fun PickerScreen(onDone: (List<Uri>) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var pics by remember { mutableStateOf<List<Pic>>(emptyList()) }
    var oldestFirst by remember { mutableStateOf(false) }
    val sel = remember { mutableStateListOf<Uri>() }

    LaunchedEffect(Unit) { if (!granted) ask.launch(perm) }
    LaunchedEffect(granted) {
        if (granted) pics = withContext(Dispatchers.IO) {
            val out = mutableListOf<Pic>()
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED),
                null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 1000) {
                    out.add(Pic(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0)), c.getLong(1)))
                }
            }
            out
        }
    }
    val shown = if (oldestFirst) pics.reversed() else pics

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onCancel) { Text("Bekor") }
            Text("Ketma-ket bosing: 1, 2, 3...", Modifier.weight(1f), fontSize = 13.sp, color = Dim)
            Button(onClick = { onDone(sel.toList()) }, enabled = sel.isNotEmpty()) {
                Text("Tayyor (${sel.size})", color = Color.Black)
            }
        }
        OutlinedButton(onClick = { oldestFirst = !oldestFirst }, Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
            Text(if (oldestFirst) "Eskilari tepada (o'zgartirish)" else "Yangilari tepada (o'zgartirish)")
        }
        if (!granted) {
            Text("Galereyaga ruxsat kerak.", Modifier.padding(16.dp))
            Button(onClick = { ask.launch(perm) }, Modifier.padding(horizontal = 16.dp)) { Text("Ruxsat berish", color = Color.Black) }
        }
        LazyVerticalGrid(
            GridCells.Fixed(3), Modifier.weight(1f).padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(shown, key = { it.uri.toString() }) { pic ->
                val idx = sel.indexOf(pic.uri)
                val thumb by produceState<ImageBitmap?>(null, pic.uri) {
                    value = withContext(Dispatchers.IO) {
                        try { ctx.contentResolver.loadThumbnail(pic.uri, Size(256, 256), null).asImageBitmap() } catch (e: Exception) { null }
                    }
                }
                Box(
                    Modifier.aspectRatio(1f).background(Color(0xFF222222))
                        .clickable { if (idx >= 0) sel.remove(pic.uri) else sel.add(pic.uri) }
                ) {
                    thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                    if (idx >= 0) {
                        Box(Modifier.fillMaxSize().border(3.dp, Accent))
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(6.dp).size(26.dp).clip(CircleShape).background(Accent),
                            contentAlignment = Alignment.Center
                        ) { Text("${idx + 1}", color = Color.Black, fontSize = 13.sp) }
                    }
                }
            }
        }
    }
}
