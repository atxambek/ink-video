package com.inkvideo.maker

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { Screen() } } }
    }
}

private fun nameOf(ctx: android.content.Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    } ?: uri.lastPathSegment.orEmpty()

private val NUM = Regex("""\d+|\D+""")
private fun naturalKey(s: String) = NUM.findAll(s.lowercase()).joinToString("|") {
    if (it.value[0].isDigit()) it.value.padStart(8, '0') else it.value
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var audio by remember { mutableStateOf<Uri?>(null) }
    var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
    var progress by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    val pickImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l ->
        images = l.sortedBy { naturalKey(nameOf(ctx, it)) }
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { audio = it }
    val pickSrt = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val text = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText().orEmpty()
            cues = parseSrt(text)
        }
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Ink Video Maker", style = MaterialTheme.typography.headlineSmall)
        Text("Rasmlar SRT vaqtlariga qarab avtomatik joylanadi (rasm №1 → SRT №1 ...). Rasm nomlari tartib bilan bo'lsin: 001.png, 002.png...")

        Button(onClick = { pickImages.launch("image/*") }, Modifier.fillMaxWidth(), enabled = !busy) {
            Text("1. Rasmlarni tanlash (${images.size})")
        }
        Button(onClick = { pickAudio.launch(arrayOf("audio/*")) }, Modifier.fillMaxWidth(), enabled = !busy) {
            Text(if (audio == null) "2. Voiceover audio tanlash" else "2. Audio tanlandi ✓")
        }
        Button(onClick = { pickSrt.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), enabled = !busy) {
            Text("3. SRT fayl tanlash (${cues.size} ta sahna)")
        }

        if (images.isNotEmpty() && cues.isNotEmpty() && images.size != cues.size)
            Text("Diqqat: ${images.size} ta rasm, ${cues.size} ta sahna. Kichigi hisobga olinadi.",
                color = MaterialTheme.colorScheme.error)

        Button(
            onClick = {
                busy = true; progress = 0; status = "Video yig'ilmoqda..."
                VideoBuilder.build(ctx, images, audio!!, cues,
                    onProgress = { progress = it },
                    onDone = { busy = false; progress = 100; status = "Tayyor: $it" },
                    onError = { busy = false; status = "Xato: $it" })
            },
            Modifier.fillMaxWidth(),
            enabled = !busy && images.isNotEmpty() && audio != null && cues.isNotEmpty()
        ) { Text("4. Videoni yaratish") }

        if (busy) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
        if (status.isNotEmpty()) Text(status)
    }
}
